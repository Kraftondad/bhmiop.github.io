<?php
$emailku = 'anshtiwari5500@gmail.com'; // GANTI EMAIL KAMU DISINI
?>